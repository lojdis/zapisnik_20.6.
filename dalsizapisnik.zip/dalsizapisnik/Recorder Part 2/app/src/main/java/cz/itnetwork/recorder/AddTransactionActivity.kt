/*  _____ _______         _                      _
 * |_   _|__   __|       | |                    | |
 *   | |    | |_ __   ___| |___      _____  _ __| | __  ___ ____
 *   | |    | | '_ \ / _ \ __\ \ /\ / / _ \| '__| |/ / / __|_  /
 *  _| |_   | | | | |  __/ |_ \ V  V / (_) | |  |   < | (__ / /
 * |_____|  |_|_| |_|\___|\__| \_/\_/ \___/|_|  |_|\_(_)___/___|
 *                                _
 *              ___ ___ ___ _____|_|_ _ _____
 *             | . |  _| -_|     | | | |     |  LICENCE
 *             |  _|_| |___|_|_|_|_|___|_|_|_|
 *             |_|
 *
 * IT ZPRAVODAJSTVÍ  <>  PROGRAMOVÁNÍ  <>  HW A SW  <>  KOMUNITA
 *
 * Tento zdrojový kód je součástí výukových seriálů na
 * IT sociální síti WWW.ITNETWORK.CZ
 *
 * Kód spadá pod licenci prémiového obsahu a vznikl díky podpoře
 * našich členů. Je určen pouze pro osobní užití a nesmí být šířen.
 * Více informací na http://www.itnetwork.cz/licence
 */

package cz.itnetwork.recorder

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import cz.itnetwork.recorder.models.Expense
import cz.itnetwork.recorder.models.Transaction
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter


class AddTransactionActivity : AppCompatActivity() {

    object companion {

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_transaction)

        val sType=findViewById<Spinner>(R.id.s_type)
        val tEAmount=findViewById<EditText>(R.id.te_amount)
        val tEDate=findViewById<EditText>(R.id.te_date)
        val btnAddTransaction=findViewById<Button>(R.id.btn_add_transaction)

        val incomeText=resources.getString(R.string.income)
        val expenceText=resources.getString(R.string.expense)

        val dataAdapter=ArrayAdapter<String>(context:this,android.R.layout.simple_spinner_item, listOf(incomeText,expenseText))

        sType.adapter=dataAdapter

        val realm=Realm.getDefaultInstance()

        companion object{
            private val formatter=DateTimeFormatter.ofPattern(pattern: "d/M/y HH:mm")
            {
                btnAddTransaction.setOnClickListener
            }
                try
            {
                val usersInputDate = LocalDateTime.parse(tEDate.text.toString(), formatter)
                val userInputAmount = tEAmount.text.toString().toInt()

                realm.beginTransaction()
                val transaction: Transaction
                if (sType.selectedItem == incomeText)
                    transaction = realm.createdObject(Income: :class.java)

                else
                transaction = realm.createObject(Expense: :class.java)
                transaction.amount = userInputAmount
                transaction.date = usersInputDate
                realm.commitTransaction()

                finish()
            }catch (e: DateTimeParseException){

            }catch(e:NumberFormatException){
        }

    }
}
